package puzzle;

import java.util.ArrayList;
import java.util.List;

public class Solver extends Object
{
	int start;
	List<String> ends;
	Solver(int start) 
	{
        this.start=start;
        System.out.println("starting solver: "+ (start+1));
    }


    void run() 
    {
        System.out.println("running solver");
        Board b = new Board(start);
        ends = new ArrayList<String>();
        runBoard(b,ends);
    }
    
    public static void runBoard(Board b, List<String> ends)
    {        
        if(!b.getPossibleMove()) {
        	ends.add(b.toString());            
            return;
        }
        
        String [] pm = Board.MOVES;
        for(int x=0;x<pm.length;++x) {
            if(b.isMoveValid(pm[x])) {
                Board nb = new Board(b);
                nb.makeMove(pm[x]);
                runBoard(nb,ends);
            }
        }        
    }
    
    public List<String> getEnds()
    {
    	return ends;
    }
       
}