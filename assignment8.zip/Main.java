package puzzle;

public class Main {

	public static void main(String[] args) 
	{
		// write your code here
        System.out.println("hello");
        for(int start=0; start<15; start++) {
            Solver solver = new Solver(start);
            solver.run();
            Display disp = new Display(start,solver.getEnds());           
            disp.show();
        }
	}
}