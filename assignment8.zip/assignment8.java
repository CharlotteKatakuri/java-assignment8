import java.util.*;

public class Solver implements Cloneable
{
    
    //       A                     0                    _ _ _ _ . _ _ _ _      [4]
    //      B C                  1  2                   _ _ _ x _ x _ _ _     [3,5]
    //     D E F                3  4  5                 _ _ x _ x _ x _ _    [2,4,6]
    //    G H I J             6  7  8  9                _ x _ x _ x _ x _   [1,3,5,7]
    //   K L M N O          10 11 12 13 14              x _ x _ x _ x _ x  [0,2,4,6,8]
    
    static final String [] MOVES = {
        "ABD","ACF",
        "BEI","BDG",
        "CEH","CFJ",
        "DBA","DEF","DHM","DGK",
        "EIN","EHL",
        "FCA","FED","FIM","FJO",
        "GDB","GHI",
        "HEC","HIJ",
        "IHG","IEB",
        "JFC","JIH",
        "KGD","KLM",
        "LHE","LMN",
        "MLK","MHD","MIF","MNO",
        "NML","NIE",
        "ONM","OJF"
    };

    List<String> moves;
    boolean [] board;
    
    // Subclass this to provide different types of boards and associated moves 
    protected String [] getMoves() {return MOVES;}
    
    public Solver(int oneMissing)
    {
        board = new boolean[15];
        moves = new ArrayList<String>();
        
        for(int x=0;x<15;++x) {
            board[x] = true;
        }
        
        board[oneMissing] = false;
    }
    
    public Solver(Solver other)
    {
        board = new boolean[other.board.length];
        for(int x=0;x<board.length;++x) {
            board[x] = other.board[x];
        }        
        moves = new ArrayList<String>(other.moves.size());    
        for(String s : other.moves) {
        	moves.add(s);
        }        
    }
    
    public static int[][] getPoint(char letter)
    {
    	int [][] p=new int[1][2];
    	switch(letter) 
    	{
          case 'A':
              p[0][0]=0;
              p[0][1]=4;
          break;
          case 'B':
        	  p[0][0]=1;
              p[0][1]=3;
          break;
          case 'C':
        	  p[0][0]=1;
              p[0][1]=5;
          break;
          case 'D':
        	  p[0][0]=2;
              p[0][1]=2;
          break;
          case 'E':
        	  p[0][0]=2;
              p[0][1]=4;;
          break;
          case 'F':
        	  p[0][0]=2;
              p[0][1]=6;
          break;
          case 'G':
        	  p[0][0]=3;
              p[0][1]=1;
          break;
          case 'H':
        	  p[0][0]=3;
              p[0][1]=3;
          break;
          case 'I':
        	  p[0][0]=3;
              p[0][1]=5;
          break;
          case 'J':
        	  p[0][0]=3;
              p[0][1]=7;
          break;
          case 'K':
        	  p[0][0]=4;
              p[0][1]=0;
          break;
          case 'L':
        	  p[0][0]=4;
              p[0][1]=2;
          break;
          case 'M':
        	  p[0][0]=4;
              p[0][1]=4;
          break;
          case 'N':
        	  p[0][0]=4;
              p[0][1]=6;
          break;
          case 'O':
        	  p[0][0]=4;
              p[0][1]=8;
          break;
        } 
    	return p;
    }
    public static int[][] getVector(char letter)
    {
    	int [][] vec=new int[5][9];
    	for(int i=0;i<5;i++)
    		for(int j=0;j<9;j++)
    			vec[i][j]=0;
    	vec[0][4]=1;
    	vec[1][3]=1;
    	vec[1][5]=1;
    	vec[2][2]=1;
    	vec[2][4]=1;
    	vec[2][6]=1;
    	vec[3][1]=1;
    	vec[3][3]=1;
    	vec[3][5]=1;
    	vec[3][7]=1;
    	vec[4][0]=1;
    	vec[4][2]=1;
    	vec[4][4]=1;
    	vec[4][6]=1;
    	vec[4][8]=1;
    	switch(letter) 
    	{
          case 'A':
              vec[0][4]=-1;
          break;
          case 'B':
        	  vec[1][3]=-1;
          break;
          case 'C':
        	  vec[1][5]=-1;
          break;
          case 'D':
        	  vec[2][2]=-1;
          break;
          case 'E':
        	  vec[2][4]=-1;
          break;
          case 'F':
        	  vec[2][6]=-1;
          break;
          case 'G':
        	  vec[3][1]=-1;
          break;
          case 'H':
        	  vec[3][3]=-1;
          break;
          case 'I':
        	  vec[3][5]=-1;
          break;
          case 'J':
        	  vec[3][7]=-1;
          break;
          case 'K':
        	  vec[4][0]=-1;
          break;
          case 'L':
        	  vec[4][2]=-1;
          break;
          case 'M':
        	  vec[4][4]=-1;
          break;
          case 'N':
        	  vec[4][6]=-1;
          break;
          case 'O':
        	  vec[4][8]=-1;
          break;
        } 
    	return vec;
    }
    
    
    public boolean isMoveValid(String m)
    {    	        
        int a = m.charAt(0)-'A';
        int b = m.charAt(1)-'A';
        int c = m.charAt(2)-'A';
        if(board[a] && board[b] && !board[c]) {
            return true;
        }
        return false;
    }
    
    public boolean getPossibleMove()
    {  
        String [] validMoves = getMoves();
        for(int x=0;x<validMoves.length;++x) {
            if(isMoveValid(validMoves[x])) {
                return true;
            }
        }
        return false;
    }
    
    public boolean makeMove(String m)
    {
        if(!isMoveValid(m)) {
            return false;
        }
        int a = m.charAt(0)-'A';
        int b = m.charAt(1)-'A';
        int c = m.charAt(2)-'A';
        board[a] = false;
        board[b] = false;
        board[c] = true;        
        moves.add(m);
        return true;
    }
    
    public int getNumberOfPegs()
    {
        int cnt = 0;
        for(int x=0;x<board.length;++x) {
            if(board[x]) {
                ++cnt;
            }
        }
        return cnt;
    }
    
    public String toString()
    {
    	String n = ""+getNumberOfPegs();
    	if(n.length()<2) n="0"+n;
        String ret = n+": ";
        for(int x=0;x<moves.size();++x) {
            ret = ret + moves.get(x);
            if(x!=(moves.size()-1)) {
                ret = ret +",";
            }
        }
        return ret;
    }
    
    public static void runBoard(Solver s, List<String> ends)
    {        
        if(!s.getPossibleMove()) {
        	ends.add(s.toString());            
            return;
        }
        
        String [] pm = s.getMoves();
        for(int x=0;x<pm.length;++x) {
            if(s.isMoveValid(pm[x])) {
                Solver ns = new Solver(s);
                ns.makeMove(pm[x]);
                runBoard(ns,ends);
            }
        }        
    }
    
    private static void Display(char mc, List<String> ends) {
		Collections.sort(ends);
		
		int [] nums = new int[11];
		
		for(String s : ends) {
			int i = s.indexOf(":");
			int a = Integer.parseInt(s.substring(0, i));
			++nums[a];
		}
		int [][] graph=new int[5][9];
        graph=getVector(mc);
        System.out.println("==="+((int)mc-64)+"=== ");
        for(int i=0;i<5;i++)
    	{		
    		for( int j=0;j<9;j++)
    	
    			{
    				if (graph[i][j]==-1)
    						System.out.print('.');
    				else if( graph[i][j]==0)
    						System.out.print(' ');
    				else
    					    System.out.print('x');
    			}
    		System.out.println();
    	}  
        System.out.println();
        String []steps=ends.get(0).substring(4).split(",");
        for(int i=0;i<13;i++)
        {   int [][] from=new int[1][2];
            from=getPoint(steps[i].charAt(0));
            int [][] over=new int[1][2];
            over=getPoint(steps[i].charAt(1));
            int [][] to=new int[1][2];
            to=getPoint(steps[i].charAt(2));
            graph[from[0][0]][from[0][1]]=-graph[from[0][0]][from[0][1]];
            graph[over[0][0]][over[0][1]]=-graph[over[0][0]][over[0][1]];
            graph[to[0][0]][to[0][1]]=-graph[to[0][0]][to[0][1]];
        	for(int ii=0;ii<5;ii++)
        	{		
        		for( int jj=0;jj<9;jj++)
        	
        			{
        				if (graph[ii][jj]==-1)
        						System.out.print('.');
        				else if( graph[ii][jj]==0)
        						System.out.print(' ');
        				else
        					    System.out.print('x');
        			}
        		System.out.println();
        	}
        	System.out.println();
        }

	}
    
    private static void doRun(char mc) {
    	int mp = mc-'A';
        Solver s = new Solver(mp);
        List<String> ends = new ArrayList<String>();
        runBoard(s,ends);
        
        Display(mc,ends);       
    }
    
    
    public static void main(String [] args) 
    {       
    	for(int i=0;i<15;i++)
    	{  
    		char choice=(char) ('A'+i);
    		doRun(choice);
    	} 
      
    }	   
}