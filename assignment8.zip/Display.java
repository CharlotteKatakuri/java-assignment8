package puzzle;

import java.util.Collections;
import java.util.List;

public class Display 
{
	int first;
	List<String> ends;
	
	Display(int first,List<String> ends)
	{
		this.first=first;
		this.ends=ends;
        System.out.println("will display");
    }

	public static int[][] getPoint(int hole)
    {
    	int [][] p=new int[1][2];
    	switch(hole) 
    	{
          case 1:
              p[0][0]=0;
              p[0][1]=4;
          break;
          case 2:
        	  p[0][0]=1;
              p[0][1]=3;
          break;
          case 3:
        	  p[0][0]=1;
              p[0][1]=5;
          break;
          case 4:
        	  p[0][0]=2;
              p[0][1]=2;
          break;
          case 5:
        	  p[0][0]=2;
              p[0][1]=4;;
          break;
          case 6:
        	  p[0][0]=2;
              p[0][1]=6;
          break;
          case 7:
        	  p[0][0]=3;
              p[0][1]=1;
          break;
          case 8:
        	  p[0][0]=3;
              p[0][1]=3;
          break;
          case 9:
        	  p[0][0]=3;
              p[0][1]=5;
          break;
          case 10:
        	  p[0][0]=3;
              p[0][1]=7;
          break;
          case 11:
        	  p[0][0]=4;
              p[0][1]=0;
          break;
          case 12:
        	  p[0][0]=4;
              p[0][1]=2;
          break;
          case 13:
        	  p[0][0]=4;
              p[0][1]=4;
          break;
          case 14:
        	  p[0][0]=4;
              p[0][1]=6;
          break;
          case 15:
        	  p[0][0]=4;
              p[0][1]=8;
          break;
        } 
    	return p;
    }
	
    public static int[][] getVector(int hole)
    {
    	int [][] vec=new int[5][9];
    	for(int i=0;i<5;i++)
    		for(int j=0;j<9;j++)
    			vec[i][j]=0;
    	vec[0][4]=1;
    	vec[1][3]=1;
    	vec[1][5]=1;
    	vec[2][2]=1;
    	vec[2][4]=1;
    	vec[2][6]=1;
    	vec[3][1]=1;
    	vec[3][3]=1;
    	vec[3][5]=1;
    	vec[3][7]=1;
    	vec[4][0]=1;
    	vec[4][2]=1;
    	vec[4][4]=1;
    	vec[4][6]=1;
    	vec[4][8]=1;
    	switch(hole) 
    	{
          case 1:
              vec[0][4]=-1;
          break;
          case 2:
        	  vec[1][3]=-1;
          break;
          case 3:
        	  vec[1][5]=-1;
          break;
          case 4:
        	  vec[2][2]=-1;
          break;
          case 5:
        	  vec[2][4]=-1;
          break;
          case 6:
        	  vec[2][6]=-1;
          break;
          case 7:
        	  vec[3][1]=-1;
          break;
          case 8:
        	  vec[3][3]=-1;
          break;
          case 9:
        	  vec[3][5]=-1;
          break;
          case 10:
        	  vec[3][7]=-1;
          break;
          case 11:
        	  vec[4][0]=-1;
          break;
          case 12:
        	  vec[4][2]=-1;
          break;
          case 13:
        	  vec[4][4]=-1;
          break;
          case 14:
        	  vec[4][6]=-1;
          break;
          case 15:
        	  vec[4][8]=-1;
          break;
        } 
    	return vec;
    }
    
    void show() 
    {
        System.out.println("displaying");
        Collections.sort(ends);
		
		int [] nums = new int[11];
		
		for(String s : ends) {
			int i = s.indexOf(":");
			int a = Integer.parseInt(s.substring(0, i));
			++nums[a];
		}
		int [][] graph=new int[5][9];
        graph=getVector(first+1);
        System.out.println("==="+(first+1)+"=== ");
        for(int i=0;i<5;i++)
    	{		
    		for( int j=0;j<9;j++)
    	
    			{
    				if (graph[i][j]==-1)
    						System.out.print('.');
    				else if( graph[i][j]==0)
    						System.out.print(' ');
    				else
    					    System.out.print('x');
    			}
    		System.out.println();
    	}  
        System.out.println();
        String []steps=ends.get(0).substring(4).split(",");
        for(int i=0;i<13;i++)
        {   int [][] from=new int[1][2];
            from=getPoint((int)(steps[i].charAt(0)-'A'+1));
            int [][] over=new int[1][2];
            over=getPoint((int)(steps[i].charAt(1)-'A'+1));
            int [][] to=new int[1][2];
            to=getPoint((int)(steps[i].charAt(2)-'A'+1));
            graph[from[0][0]][from[0][1]]=-graph[from[0][0]][from[0][1]];
            graph[over[0][0]][over[0][1]]=-graph[over[0][0]][over[0][1]];
            graph[to[0][0]][to[0][1]]=-graph[to[0][0]][to[0][1]];
        	for(int ii=0;ii<5;ii++)
        	{		
        		for( int jj=0;jj<9;jj++)
        	
        			{
        				if (graph[ii][jj]==-1)
        						System.out.print('.');
        				else if( graph[ii][jj]==0)
        						System.out.print(' ');
        				else
        					    System.out.print('x');
        			}
        		System.out.println();
        	}
        	System.out.println();
        }
    }

}