package puzzle;

import java.util.ArrayList;
import java.util.List;

    public class Board 
    {
    //       A                     0                    _ _ _ _ . _ _ _ _      [4]
    //      B C                  1  2                   _ _ _ x _ x _ _ _     [3,5]
    //     D E F                3  4  5                 _ _ x _ x _ x _ _    [2,4,6]
    //    G H I J             6  7  8  9                _ x _ x _ x _ x _   [1,3,5,7]
    //   K L M N O          10 11 12 13 14              x _ x _ x _ x _ x  [0,2,4,6,8]

    public static final String [] MOVES = {
       "ABD","ACF",
       "BEI","BDG",
       "CEH","CFJ",
       "DBA","DEF","DHM","DGK",
       "EIN","EHL",
       "FCA","FED","FIM","FJO",
       "GDB","GHI",
       "HEC","HIJ",
       "IHG","IEB",
       "JFC","JIH",
       "KGD","KLM",
       "LHE","LMN",
       "MLK","MHD","MIF","MNO",
       "NML","NIE",
       "ONM","OJF"
    };
    public List<String> moves;
    boolean [] board;
    
	Board(int start) 
	{
		board = new boolean[15];
        moves = new ArrayList<String>();        
        for(int x=0;x<15;++x) {
            board[x] = true;
        }
        
        board[start] = false;
        System.out.println("board ready");
    }
	
	public Board(Board other)
    {
        board = new boolean[15];
        for(int x=0;x<15;++x) {
            board[x] = other.board[x];
        }        
        moves = new ArrayList<String>(other.moves.size());    
        for(String s : other.moves) {
        	moves.add(s);
        }        
    }
	 public boolean isMoveValid(String m)
	    {    	        
	        int a = m.charAt(0)-'A';
	        int b = m.charAt(1)-'A';
	        int c = m.charAt(2)-'A';
	        if(board[a] && board[b] && !board[c]) {
	            return true;
	        }
	        return false;
	    }
	    
	    public boolean getPossibleMove()
	    {  
	        String [] validMoves = Board.MOVES;
	        for(int x=0;x<validMoves.length;++x) {
	            if(isMoveValid(validMoves[x])) {
	                return true;
	            }
	        }
	        return false;
	    }
	    
	    public boolean makeMove(String m)
	    {
	        if(!isMoveValid(m)) {
	            return false;
	        }
	        int a = m.charAt(0)-'A';
	        int b = m.charAt(1)-'A';
	        int c = m.charAt(2)-'A';
	        board[a] = false;
	        board[b] = false;
	        board[c] = true;        
	        moves.add(m);
	        return true;
	    }
	    
	    public int getNumberOfPegs()
	    {
	        int cnt = 0;
	        for(int x=0;x<board.length;++x) {
	            if(board[x]) {
	                ++cnt;
	            }
	        }
	        return cnt;
	    }
	    
	    public String toString()
	    {
	    	String n = ""+getNumberOfPegs();
	    	if(n.length()<2) n="0"+n;
	        String ret = n+": ";
	        for(int x=0;x<moves.size();++x) {
	            ret = ret + moves.get(x);
	            if(x!=(moves.size()-1)) {
	                ret = ret +",";
	            }
	        }
	        return ret;
	    }	
}